window.onload = function () {

    var buys = 0;
    var arr = [];

    var browseMenu = document.getElementsByClassName('browse_menu');
    var ok = document.getElementById('ok');
    browseMenu[0].style.display = "none";
    var cartHide = document.getElementsByClassName('cart-hide');
    cartHide[0].style.display = "none";

    function addToCart(event) {
        if (event.target.classList.contains('blockhover') || event.target.classList.contains('block')
            || event.target.classList.contains('sprite-forma-1')) {

            ++buys;

            var sumPrice = 0;
            document.getElementsByClassName('items_number')[0].style.display = 'block';
            document.getElementById('item_number').innerHTML = buys;

            var fetured_item = event.currentTarget;

            var image = fetured_item.getElementsByClassName('item_back')[0].children[0];

            var title = fetured_item.getElementsByClassName('fetured_text')[0].innerHTML;
            var price = fetured_item.getElementsByClassName('fetured_price')[0].innerHTML;
            var rating = fetured_item.getElementsByClassName('stars')[0];

            var cartItem = document.createElement('div');
            cartItem.classList.add('cart-hide_item');
            var imageClone = image.cloneNode(true);
            imageClone.classList.remove('item_img');
            imageClone.classList.add('cart-hide-img1');

            var element = fetured_item.getElementsByClassName('item_back')[0].children[0];
            var itemCart = element.id + '_cart';
            imageClone.id = itemCart;
            var IdItemCart = document.getElementById(itemCart);

            cartItem.appendChild(imageClone);

            var cartTitle = document.createElement('div');
            cartTitle.classList.add('cart-hide-text');
            var name = document.createElement('h4');
            name.innerHTML = title;
            cartTitle.appendChild(name);
            var ratingClone = rating.cloneNode(true);
            ratingClone.classList.remove('stars_fetured');
            cartTitle.appendChild(ratingClone);

            var priceAndNum = document.createElement('p');
            priceAndNum.innerHTML = '<span class="units">1</span> ' + ' <span>x</span> ' + price;
            cartTitle.appendChild(priceAndNum);
            cartItem.appendChild(cartTitle);

            var cartDelete = document.createElement('div');
            cartDelete.classList.add('cart-hide-delete');
            cartDelete.innerHTML = '<i class="fa fa-times-circle" aria-hidden="true"></i>';
            cartItem.appendChild(cartDelete);

            /*
            document.
            for (j=0;j<
                var price_number = parseInt(price);
            */

            var totalPrice = 0;
            if (!IdItemCart) {
                cartHide[0].insertBefore(cartItem, cartHide[0].firstChild);
                arr.push(price);
            } else {
                var parent = IdItemCart.parentElement;
                var nums = parent.getElementsByClassName('units')[0].innerHTML;
                nums++;
                parent.getElementsByClassName('units')[0].innerHTML = nums;
                arr.push(price);
            }
            for (var i = 0; i < arr.length; i++) {
                totalPrice = totalPrice + parseInt(arr[i]);
            }
            document.getElementById('total_price').innerHTML = totalPrice;
        }
    }


    cartHide[0].addEventListener('click', function (event) {
        event.stopPropagation();
    })
    browseMenu[0].addEventListener('click', function (event) {
        event.stopPropagation();
    })

    function showHide(event) {
        if (event.target.classList.contains('header_browse') && (browseMenu[0].style.display === "none")) {
            browseMenu[0].style.display = "flex";
        } else if (event.target.classList.contains('header_browse') && (browseMenu[0].style.display = "flex")) {
            browseMenu[0].style.display = "none";
        } else if (event.target.classList.contains('cart') && (cartHide[0].style.display === "none")) {
            cartHide[0].style.display = "flex";
        } else if (event.target.classList.contains('cart') && (cartHide[0].style.display === "flex")) {
            cartHide[0].style.display = "none";
        } else {
            browseMenu[0].style.display = "none";
            cartHide[0].style.display = "none";
        }
    }

    document.body.addEventListener('click', showHide);
    var fetured_item = document.getElementsByClassName('fetured_item');
    for (i = 0; i < fetured_item.length; i++) {
        fetured_item[i].addEventListener('click', addToCart);
    }
}